10.5.12.5 client,windows xp
10.5.3.1  KDC, Windows 2003 Domain Controller
10.5.15.5 Apache with Kerberos enabled mod, on Fedora Core 4
Generated on January 6, 2020 by Tomasz Moń <desowin@gmail.com>

When generating the capture files following devices were present:
  * Laptop1
  * Laptop2
  * OpenVizsla USB sniffer
  * LambdaConcept USB2Sniffer
  * i-tec USB 2.0 7-Port Hub (High-Speed)
  * Creative SoundBlaster SB1240 (Full-Speed)

OpenVizsla USB sniffer was connected to Laptop2, monitoring FS link between SB1240 and i-tec Hub.
LambdaConcept USB2Sniffer was connected to Laptop1 USB 3.0 port, monitoring HS link between Laptop1 and i-tec Hub.
i-tec Hub was connected to Laptop1.
SB1240 was connected to i-tec Hub.

All captures contain the same payload (captures at the same time).

Capture steps:
  1. Connect all devices, except for the i-tec USB upstream port
  2. Start capturing (OpenVizsla, LambdaConcept USB2Sniffer, usbmon on Laptop1)
  3. Connect i-tec USB upstream port to Laptop1
  4. Wait
  5. Disconnect i-tec USB upstream port
  6. Stop captures

The 7-port hub is seen by USB Host as two 4-port hubs (the "2nd" 4-port hub is connected to the "1st" one, leaving 7 ports available for external devices).

The traces contain following USB addresses:
0  - default address for newly connected device (before SET ADDRESS)
30 - "1st" 4-port hub (inside i-tec USB 2.0 7-Port Hub)
23 - "2nd" 4-port hub (inside i-tec USB 2.0 7-Port Hub)
3  - SB1240

File descriptions:
  * SB1240-via-hub-FS-link-filtered.pcap
    Full-Speed communication between the i-tec Hub and SB1240 as captured by OpenVizsla.
    This file is filtered, i.e. without the SOFs and NAKed transactions.
  * SB1240-via-hub-FS-link.pcap
    Full-Speed communication between the i-tec Hub and SB1240 as captured by OpenVizsla.
    This file contains all USB packets, i.e. with SOFs and NAKed transactions.
  * SB1240-via-hub-HS-link.pcap
    High-Speed communication between Laptop1 and i-tec Hub as captured by LambdaConcept USB2Sniffer.
  * SB1240-via-hub-HS-link.usb
    Same as SB1240-via-hub-HS-link.pcap, except in the format used by LambaConcept usb2sniffer-qt utility.
  * SB1240-via-hub-usbmon.pcapng
    Laptop1 usbmon capture

Notice that only the HS link captures contain SPLIT transactions.

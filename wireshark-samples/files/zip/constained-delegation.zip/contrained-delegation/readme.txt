10.5.12.12 client, IE on Windows XP
10.5.3.1   KDC, Windows 2003 domain controller
10.5.2.2   IIS6 on Windows 2003 member server. Trusted for CIFS service on DC.

An ASP page will access a file share on DC using client's credential.
